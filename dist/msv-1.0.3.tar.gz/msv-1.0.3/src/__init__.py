# src/__init__.py
"""MSV - Merge Source Values."""
from .version import __version__
__all__ = ['__version__']