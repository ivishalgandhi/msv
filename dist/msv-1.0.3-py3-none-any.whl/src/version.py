"""Version information for MSV package."""

__version__ = "1.0.3"

def get_version():
    """Return the current version of MSV."""
    return __version__